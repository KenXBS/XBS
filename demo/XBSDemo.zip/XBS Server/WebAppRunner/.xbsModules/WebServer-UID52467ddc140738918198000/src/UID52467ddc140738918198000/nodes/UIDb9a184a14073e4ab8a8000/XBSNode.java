package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.servlet.ServletException;
import org.apache.catalina.Engine;
import org.apache.catalina.Host;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Embedded;

import UID52467ddc140738918198000.module.*;
import com.kensoft.xbs.xbsEngine.*;

public class XBSNode extends NodeBase {
	private Embedded embedded = null;
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nc=(XBSNodeContext) arg0;
		XBSModuleContext mc=(XBSModuleContext) arg0.getModuleContext();
		
		Host host = null;
	    Engine engine = null;
	    
	    // Create an embedded server
	    embedded = new Embedded();
	    embedded.setName("XBS Engine");
    
	    // print all log statments to standard error

	    // Create an engine
	    engine = embedded.createEngine();
	    engine.setName("XBS Engine");

	    // Install the assembled container hierarchy
	    embedded.addEngine(engine);

	 // Create a default virtual host
	   
	    String path1;
		try {
			path1 = new File(nc.INPUT_WebContentPath).getCanonicalPath();
			host = embedded.createHost("localhost", path1);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			return nc.Outcome_Start_failed(e2.getLocalizedMessage());
		}
	    

	    //create servlet context
	    
	    XBSServerHttpServlet mainServlet=new XBSServerHttpServlet(this, mc);
	    try {
			mainServlet.init();
		} catch (ServletException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return this.Outcome_Start_failed("Http server failed to start. Exception: " + e1.getMessage());
		}
	    host.addChild(new XBSServerServletContext("/", path1, mainServlet));
	    
	    engine.addChild(host);
	    engine.setDefaultHost(host.getName()); 
	    
	    // Assemble and install a default HTTP connector
	    InetAddress addr=null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return this.Outcome_Start_failed("Failed to get localhost IP: " + e1.getLocalizedMessage());
		}
	    Connector connector =
	      embedded.createConnector(addr.getHostAddress(), nc.INPUT_Port, false);
	    embedded.addConnector(connector);
	   
	    connector =
	  	      embedded.createConnector("localhost", nc.INPUT_Port, false);
	  	    embedded.addConnector(connector);
	  	
	  	String path = mc.getRootPath() + "/tomcat";
	  	if(!new File(path).exists()){
	  		return this.Outcome_Start_failed("Tomcat folder doesn't exist. path: " + path);
	  	}
	  	
	    embedded.setCatalinaBase(path);
	    
	    // Start the embedded server
	    try {
			embedded.start();
			//System.out.println("Host app base: " + host.setAppBase("C:/Users/Ken/Documents/XBS new/projects/Enhance Interface/Test For Enhance Interface/WebContent"));
	    } catch (LifecycleException e) {
			e.printStackTrace();
			return this.Outcome_Start_failed("Http server failed to start. Exception: " + e.getMessage());
		}	
		
		return this.Outcome_Start_success(null);
	
	}

	
	@Override
	protected OUTCOME_Call_STOP_SERVICE CALL_Stop_Service() {
		try {
			embedded.stop();
			this.FireEvent_Service_stopped();
			return OUTCOME_Call_STOP_SERVICE.Succeed();
		} catch (LifecycleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return OUTCOME_Call_STOP_SERVICE.Failed(e.getLocalizedMessage());
		}
	}


}