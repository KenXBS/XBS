package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XBSRedirectHttpServlet extends HttpServlet {
	public String toString() { return "XBSServerRedirectHttpServlet"; };
	private Logger m_logger;
	
	public XBSRedirectHttpServlet(){
		m_logger=Logger.getLogger(this.getClass().getName());
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//m_logger.info("Http request path: " + req.getPathInfo());
		//resp.sendRedirect("/action?app=" + req.getPathInfo().substring(1));
		super.doGet(req, resp);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3849131924215620894L;

}
