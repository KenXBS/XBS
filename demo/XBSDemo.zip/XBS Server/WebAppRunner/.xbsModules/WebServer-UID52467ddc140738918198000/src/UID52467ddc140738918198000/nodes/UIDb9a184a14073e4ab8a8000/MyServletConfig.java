package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

public class MyServletConfig implements ServletConfig {
	private final ServletContext m_sc;
	
	MyServletConfig(ServletContext sc){
		m_sc=sc;
	}
	
	@Override
	public String getInitParameter(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Enumeration getInitParameterNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServletContext getServletContext() {
		// TODO Auto-generated method stub
		return m_sc;
	}

	@Override
	public String getServletName() {
		return XBSServerHttpServlet.name;
	}

}
