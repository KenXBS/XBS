package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

import org.apache.catalina.Lifecycle;
import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.ContextConfig;

public class XBSServerServletContext extends StandardContext {

	final ServletContext m_servletContext;
	final XBSServerHttpServlet m_servlet;
	XBSServerServletContext(String path, String docBase, XBSServerHttpServlet servlet){
		System.out.println("DocBase: " + docBase + ", Path: " + path);
        super.setDocBase(docBase);
        super.setPath(path);
        ContextConfig config = new ContextConfig();
        //config.setCustomAuthenticators(authenticators);
        ((Lifecycle) this).addLifecycleListener(config);
        
        m_servlet=servlet;
        super.addChild(new XBSServerHttpWrapper(m_servlet));
        super.addServletMapping("/*", m_servlet.toString());
        
        //redirect servlet
        
//        HttpServlet servletRedirect=new XBSRedirectHttpServlet();
//        super.addChild(new XBSServerHttpWrapper(servletRedirect));
//        super.addServletMapping("/*", servletRedirect.toString());
        
        
        m_servletContext=new MySerlvetContext(m_servlet);
        m_servlet.setServletConfig(new MyServletConfig(m_servletContext));
	}
	@Override
	public ServletContext getServletContext() {
		super.getServletContext();
		return m_servletContext;
	}

	@Override
	public String[] getServlets() {
		// TODO Auto-generated method stub
		return super.getServlets();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -5024518582922365987L;

}
