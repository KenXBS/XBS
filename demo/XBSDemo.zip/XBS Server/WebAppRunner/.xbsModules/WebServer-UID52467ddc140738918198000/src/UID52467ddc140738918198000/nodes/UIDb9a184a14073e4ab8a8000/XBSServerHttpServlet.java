package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import java.io.IOException;
import org.apache.log4j.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UID52467ddc140738918198000.module.*;

class XBSServerHttpServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3952003716449852314L;
	
	static final String name="XBSServerMainHttpServlet";
	public String toString() { return name; };
	private Logger m_logger;
	private XBSNode m_node=null;
	private final XBSModuleContext m_mc;
	private ServletConfig m_servletConfig;
	
	
	@Override
	public ServletConfig getServletConfig() {
		return m_servletConfig;
	}


	void setServletConfig(ServletConfig sc){
		m_servletConfig=sc;
	}
	XBSServerHttpServlet(XBSNode node, XBSModuleContext mc){
		m_logger=Logger.getLogger(this.getClass().getName());
		m_mc=mc;
		m_node=node;
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
			m_node.INVOKE_CALL_Service(null, req, resp);	
		} catch (Exception e) {
			m_logger.error("Exception while making call of 'Service' : " + e.getLocalizedMessage());
		}
	}

	public void finalized(){
		m_logger.info("XBS Server Http servlet shut down.");
	}
	




}
