package UID19b9861f1498bdaae9e7ffc.nodes.UIDb772d6c1498c1da1787ffc;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_EXCEPTION extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc_service_failed";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_EXCEPTION";}
		public String toString(){ return "OUTCOME_EXCEPTION";}
		public final String OUTPUT_ErrorMessage;
		public final static String OUTPUT_ID_ErrorMessage="oc_service_failed_message_id";

		OUTCOME_EXCEPTION(String ErrorMessage){
			OUTPUT_ErrorMessage = ErrorMessage;
		}

		public Object getOutputValue(String outputId){
			if("oc_service_failed_message_id".equals(outputId)){
				 return OUTPUT_ErrorMessage;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Exception(String ErrorMessage){
		 return new OUTCOME_EXCEPTION( ErrorMessage);
	}
	protected class OUTCOME_START_SUCCESS extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc_service_success";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_START_SUCCESS";}
		public String toString(){ return "OUTCOME_START_SUCCESS";}
		public final String OUTPUT_ServiceHandle;
		public final static String OUTPUT_ID_ServiceHandle="output_service_handle_id";

		OUTCOME_START_SUCCESS(String ServiceHandle){
			OUTPUT_ServiceHandle = ServiceHandle;
		}

		public Object getOutputValue(String outputId){
			if("output_service_handle_id".equals(outputId)){
				 return OUTPUT_ServiceHandle;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Start_success(String ServiceHandle){
		 return new OUTCOME_START_SUCCESS( ServiceHandle);
	}
	public XBSOutcome call(String callId, Map<String, Object> inputs) throws NotFoundEntryException{
		if("service_call_stop".equals(callId)) return CALL_Stop_Service();
		else if("UIDb772d6c1498c1da1787ff9".equals(callId)) return CALL_HttpRequest((Object) inputs.get("UIDb9a184a14073e4ab8a7ffd"), (Object) inputs.get("UIDb9a184a14073e4ab8a7ffc"));
		else throw new NotFoundEntryException(callId);
	}
	protected static class OUTCOME_Call_STOP_SERVICE extends XBSOutcome {
		private static final long serialVersionUID = 1L;
		class OUTCOME_SUCCEED extends OUTCOME_Call_STOP_SERVICE{
			private static final long serialVersionUID = 1L;
			public final static String id="service_call_stop_oc_success";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_SUCCEED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_SUCCEED(){
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

		}
		static OUTCOME_Call_STOP_SERVICE Succeed(){
			return new OUTCOME_Call_STOP_SERVICE().new OUTCOME_SUCCEED();
		};
		class OUTCOME_FAILED extends OUTCOME_Call_STOP_SERVICE{
			private static final long serialVersionUID = 1L;
			public final static String id="service_call_stop_oc_failed";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_FAILED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_FAILED(String ErrorMessage){
				m_outputs.put("service_call_stop_oc_failed_output_error", ErrorMessage);
				OUTPUT_ErrorMessage = (String) getOutputValue("service_call_stop_oc_failed_output_error");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_ErrorMessage;
		}
		static OUTCOME_Call_STOP_SERVICE Failed(String ErrorMessage){
			return new OUTCOME_Call_STOP_SERVICE().new OUTCOME_FAILED( ErrorMessage);
		};
	}
	protected abstract OUTCOME_Call_STOP_SERVICE CALL_Stop_Service();
	protected static class OUTCOME_Call_HTTPREQUEST extends XBSOutcome {
		private static final long serialVersionUID = 1L;
		class OUTCOME_EXCEPTION extends OUTCOME_Call_HTTPREQUEST{
			private static final long serialVersionUID = 1L;
			public final static String id="UIDb9a184a14073e4ab8a7ff8";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_EXCEPTION"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_EXCEPTION(String Error){
				m_outputs.put("UIDb9a184a14073e4ab8a7ff7", Error);
				OUTPUT_Error = (String) getOutputValue("UIDb9a184a14073e4ab8a7ff7");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_Error;
		}
		static OUTCOME_Call_HTTPREQUEST Exception(String Error){
			return new OUTCOME_Call_HTTPREQUEST().new OUTCOME_EXCEPTION( Error);
		};
		class OUTCOME_SUCCESS extends OUTCOME_Call_HTTPREQUEST{
			private static final long serialVersionUID = 1L;
			public final static String id="UID11d97aec1407963cf287ff5";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_SUCCESS"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_SUCCESS(){
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

		}
		static OUTCOME_Call_HTTPREQUEST Success(){
			return new OUTCOME_Call_HTTPREQUEST().new OUTCOME_SUCCESS();
		};
	}
	protected abstract OUTCOME_Call_HTTPREQUEST CALL_HttpRequest(Object HttpRequest, Object HttpResponse);
	//Event (Out): service_event_stopped
	protected void FireEvent_Service_stopped(){
		Map<String, Object> inputs=new HashMap<String, Object>();
		super.fireEvent("service_event_stopped", inputs);
	}
}
