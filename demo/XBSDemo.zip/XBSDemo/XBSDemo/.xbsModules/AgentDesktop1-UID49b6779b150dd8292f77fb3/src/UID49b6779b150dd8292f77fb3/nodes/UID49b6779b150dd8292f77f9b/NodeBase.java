package UID49b6779b150dd8292f77fb3.nodes.UID49b6779b150dd8292f77f9b;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_CLOSED extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID49b6779b150dd8292f77f9a";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_CLOSED";}
		public String toString(){ return "OUTCOME_CLOSED";}
		public final String OUTPUT_UserName;
		public final static String OUTPUT_ID_UserName="UID49b6779b150dd8292f77f99";
		public final String OUTPUT_Pwd;
		public final static String OUTPUT_ID_Pwd="UID49b6779b150dd8292f77f98";

		OUTCOME_CLOSED(String UserName, String Pwd){
			OUTPUT_UserName = UserName;
			OUTPUT_Pwd = Pwd;
		}

		public Object getOutputValue(String outputId){
			if("UID49b6779b150dd8292f77f99".equals(outputId)){
				 return OUTPUT_UserName;
			}
			else if("UID49b6779b150dd8292f77f98".equals(outputId)){
				 return OUTPUT_Pwd;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Closed(String UserName, String Pwd){
		 return new OUTCOME_CLOSED( UserName,  Pwd);
	}
}
