package UID49b6779b150dd8292f77fb3.nodes.UID49b6779b150dd8292f77f93;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_EXCEPTION extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc-buildin-exception-id";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_EXCEPTION";}
		public String toString(){ return "OUTCOME_EXCEPTION";}
		public final String OUTPUT_Error;
		public final static String OUTPUT_ID_Error="Auto generated ERROR_Message id";

		OUTCOME_EXCEPTION(String Error){
			OUTPUT_Error = Error;
		}

		public Object getOutputValue(String outputId){
			if("Auto generated ERROR_Message id".equals(outputId)){
				 return OUTPUT_Error;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Exception(String Error){
		 return new OUTCOME_EXCEPTION( Error);
	}
	protected class OUTCOME_SUCCESS extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID49b6779b150dd8292f77f92";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_SUCCESS";}
		public String toString(){ return "OUTCOME_SUCCESS";}

		OUTCOME_SUCCESS(){
		}

		public Object getOutputValue(String outputId){
			throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Success(){
		 return new OUTCOME_SUCCESS();
	}
}
