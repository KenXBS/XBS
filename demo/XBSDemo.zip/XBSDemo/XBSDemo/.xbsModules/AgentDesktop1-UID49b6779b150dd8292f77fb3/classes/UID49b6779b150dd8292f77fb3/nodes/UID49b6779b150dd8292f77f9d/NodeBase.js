/**
 * Auto-generated Code for Node: AgentDesk1:Blocked Msg
 */

XBS.NODE_UID49b6779b150dd8292f77f9d_UID49b6779b150dd8292f77fb3 = function(nodeIns){
	this.nodeIns=nodeIns;
};
XBS.NODE_UID49b6779b150dd8292f77f9d_UID49b6779b150dd8292f77fb3.prototype.run=function(inputs){
	this.start();
}
/**
 * Node Outcome: Finish
 */
XBS.NODE_UID49b6779b150dd8292f77f9d_UID49b6779b150dd8292f77fb3.prototype.NodeEnd_Finish=function(){
	var that=this;
	var outputs={
	};
	setTimeout(function(){ that.nodeIns.commit("UID49b6779b150dd8292f77f9c", outputs);} , 50);
};


/**
 * The following functions need to be implemented in node implementation file. Do not edit in this file !!! 
 */
XBS.NODE_UID49b6779b150dd8292f77f9d_UID49b6779b150dd8292f77fb3.prototype.start=function(){
	//TODO: need to be coded in separate node implementation file. Do not modify here !!!

	throw "Node start() is not implemented, node: AgentDesk1:Blocked Msg";
}
