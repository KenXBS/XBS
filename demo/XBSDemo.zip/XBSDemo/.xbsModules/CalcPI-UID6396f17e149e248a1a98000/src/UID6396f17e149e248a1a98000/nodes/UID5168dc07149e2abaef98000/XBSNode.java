package UID6396f17e149e248a1a98000.nodes.UID5168dc07149e2abaef98000;

import java.util.ArrayList;

import UID6396f17e149e248a1a98000.module.*;
import org.apache.log4j.Logger;
import com.kensoft.xbs.xbsEngine.*;
public class XBSNode extends NodeBase {
	private Logger m_logger;
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nodeContext=(XBSNodeContext) arg0;
		m_logger=(Logger) nodeContext.getAttribute(XBSNodeContextBase.Sys_Log);
		XBSModuleContext moduleContext=(XBSModuleContext) arg0.getModuleContext();
		
		final int[] Rs = new int[]{10, 1000, 100};
		ArrayList<Thread> threads = new ArrayList<Thread>();
		for(final int r : Rs){
			Thread thread = new Thread(){

				@Override
				public void run() {
					Thread_CalcPI(r);
				}
				
			};
			thread.start();
			
			threads.add(thread);
			
		}
		
		/* Wait for threads to finish */
		for(Thread t : threads){
			try {
				t.join();
			} catch (InterruptedException e) {
			}
		}
		return nodeContext.Outcome_Success();
	}
	
	private void Thread_CalcPI(int r){
		try {
			OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS ocSuccess = 
					(OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS) this.INVOKE_CALL_GetPI(null, r);
			
			m_logger.info("R=" + r + ", PI=" + ocSuccess.OUTPUT_pi);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}