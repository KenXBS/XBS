package UID6396f17e149e248a1a98000.nodes.UID6396f17e149e248a1a97ffe;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_SUCCESS extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID5168dc07149e2abaef97ffd";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_SUCCESS";}
		public String toString(){ return "OUTCOME_SUCCESS";}
		public final float OUTPUT_pi;
		public final static String OUTPUT_ID_pi="UID5168dc07149e2abaef97ffb";

		OUTCOME_SUCCESS(float pi){
			OUTPUT_pi = pi;
		}

		public Object getOutputValue(String outputId){
			if("UID5168dc07149e2abaef97ffb".equals(outputId)){
				 return OUTPUT_pi;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Success(float pi){
		 return new OUTCOME_SUCCESS( pi);
	}
	//------- Sink: GetDistance [UID6396f17e149e248a1a97fed]
	interface OUTCOME_INVOKE_CALL_GETDISTANCE {
			class OUTCOME_SUCCESS extends XBSOutcome implements OUTCOME_INVOKE_CALL_GETDISTANCE{
				private static final long serialVersionUID = 1L;
				public final static String id="UID6396f17e149e248a1a97ff3";
				private String m_ocId=id;
				public String getOutcomeId(){ return m_ocId ;}
				public void resetID(String newID){ m_ocId=newID; }
				public String getOutcomeName(){ return "OUTCOME_SUCCESS";}
				public String toString(){ return "OUTCOME_SUCCESS";}
				public final double OUTPUT_distance;
				public final static String OUTPUT_ID_distance="UID6396f17e149e248a1a97ff0";

				OUTCOME_SUCCESS(double distance){
					OUTPUT_distance = distance;
				}
				private OUTCOME_SUCCESS(XBSOutcome oc){
					OUTPUT_distance = (Double) oc.getOutputValue("UID6396f17e149e248a1a97ff0");				}

				public Object getOutputValue(String outputId){
					if("UID6396f17e149e248a1a97ff0".equals(outputId)){
						 return OUTPUT_distance;
					}
					else throw new RuntimeException("Not found the output");
				}
			}
			class OUTCOME_NotFoundNodeInstance extends XBSOutcome implements OUTCOME_INVOKE_CALL_GETDISTANCE{
				private static final long serialVersionUID = 1L;
			}
	}
	protected OUTCOME_INVOKE_CALL_GETDISTANCE INVOKE_CALL_GetDistance(NodeInstanceHandle handle , int x , int y) throws Exception{
		Map<String, Object> inputs=new HashMap<String, Object>();
		inputs.put("UID6396f17e149e248a1a97ff2", x);
		inputs.put("UID6396f17e149e248a1a97ff1", y);
		XBSOutcome oc=super.call(handle, "UID6396f17e149e248a1a97fed", inputs);
		if(oc==null) throw new Exception("Call interface returns NULL of outcome");
		if(OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS.id.equals(oc.getOutcomeId())){ return new OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS(oc);}
		else if(OC_NotFoundRunningNodeInstance.ID.equals(oc.getOutcomeId())){ return new OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_NotFoundNodeInstance(); }
		else if(oc instanceof OC_EngineException){ throw new Exception( (String) oc.getOutputValue(OC_EngineException.ID_Error_Message)); }
		throw new EngineException_Unkown_Outcome(oc.getOutcomeId());
	}
	protected abstract class INVOKE_CALL_CB_GetDistance extends AsyncCallBack {
		protected INVOKE_CALL_CB_GetDistance(Object value) { super(value); } 
		@Override
		public void back(XBSOutcome outcome) throws NotFoundEntryException {
			OUTCOME_INVOKE_CALL_GETDISTANCE oc=null;
			if(outcome.getOutcomeId().equals(OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS.id)) oc=new OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS( outcome );
			else throw new NotFoundEntryException("Not found corresponding outcome in callback!?");
			finish(oc);
		}

		abstract void finish(OUTCOME_INVOKE_CALL_GETDISTANCE outcome);
	}
	protected AsyncCallOutcome INVOKE_CALL_Asyn_GetDistance (NodeInstanceHandle handle, INVOKE_CALL_CB_GetDistance cb , Integer x, Integer y){
		Map<String, Object> inputs=new HashMap<String, Object>();
		inputs.put("UID6396f17e149e248a1a97ff2", x);
		inputs.put("UID6396f17e149e248a1a97ff1", y);
		return super.call_async(handle, "UID6396f17e149e248a1a97fed", inputs, cb);
	}
	// ----------------------------------
}
