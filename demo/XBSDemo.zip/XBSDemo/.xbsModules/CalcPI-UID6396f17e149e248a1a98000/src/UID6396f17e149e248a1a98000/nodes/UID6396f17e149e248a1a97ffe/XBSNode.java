package UID6396f17e149e248a1a98000.nodes.UID6396f17e149e248a1a97ffe;

import UID6396f17e149e248a1a98000.module.*;
import org.apache.log4j.Logger;
import com.kensoft.xbs.xbsEngine.*;
public class XBSNode extends NodeBase {
	private Logger m_logger;
	private Object lock = new Object();
	private volatile int hits=0;
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nodeContext=(XBSNodeContext) arg0;
		m_logger=(Logger) nodeContext.getAttribute(XBSNodeContextBase.Sys_Log);
		XBSModuleContext moduleContext=(XBSModuleContext) arg0.getModuleContext();
		
		final int r = nodeContext.INPUT_r;
		
		Thread thread =new Thread(){
			@Override
			public
			void run(){
				Thread(r,  -r, 0);
			}
		};
		
		thread.start();
		
		
		Thread thread2 =new Thread(){
			@Override
			public
			void run(){
				Thread(r,  1, r);
			}
		};
		
		thread2.start();
		
		try {
			thread.join();
			thread2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try{

//			for(int y = -r; y<= r; y++){
//				for(int x= -r; x<= r; x++){
////					double dist = (double) Math.sqrt(Math.abs(x*x) + Math.abs(y*y));
////					if(dist <= r) hits++;
//					
//					OUTCOME_INVOKE_CALL_GETDISTANCE oc = this.INVOKE_CALL_GetDistance(null, x, y);
//					OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS ocSuccess = 
//							(OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS) oc;
//					if(ocSuccess.OUTPUT_distance <= r) hits++;
//					
//				}
//			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			return nodeContext.Outcome_Success(-1);
		}
		
		return nodeContext.Outcome_Success((float)hits/(r*r));
	}
	
	private void Thread(int r, int y1, int y2){
		for(int y = y1; y<= y2; y++){
			for(int x= -r; x<= r; x++){
//				double dist = (double) Math.sqrt(Math.abs(x*x) + Math.abs(y*y));
//				if(dist <= r) hits++;
				
				OUTCOME_INVOKE_CALL_GETDISTANCE oc;
				try {
					oc = this.INVOKE_CALL_GetDistance(null, x, y);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return;
				}
				OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS ocSuccess = 
						(OUTCOME_INVOKE_CALL_GETDISTANCE.OUTCOME_SUCCESS) oc;
				if(ocSuccess.OUTPUT_distance <= r) {
					synchronized(lock){
						++hits;
					}
				}
				
			}
		}
	}
}