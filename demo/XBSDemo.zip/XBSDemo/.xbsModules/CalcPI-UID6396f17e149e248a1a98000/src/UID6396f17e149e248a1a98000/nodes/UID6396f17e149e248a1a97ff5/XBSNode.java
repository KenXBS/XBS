package UID6396f17e149e248a1a98000.nodes.UID6396f17e149e248a1a97ff5;

import UID6396f17e149e248a1a98000.module.*;
import org.apache.log4j.Logger;
import com.kensoft.xbs.xbsEngine.*;
public class XBSNode extends NodeBase {
	private Logger m_logger;
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nodeContext=(XBSNodeContext) arg0;
		m_logger=(Logger) nodeContext.getAttribute(XBSNodeContextBase.Sys_Log);
		XBSModuleContext moduleContext=(XBSModuleContext) arg0.getModuleContext();
		
		return nodeContext.Outcome_Start_success(null);
	}
	@Override
	protected OUTCOME_Call_STOP_SERVICE CALL_Stop_Service() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	protected OUTCOME_Call_GETDISTANCE CALL_GetDistance(Integer x, Integer y) {
		// sqrt(x*x + y*y)
		return OUTCOME_Call_GETDISTANCE.Success(Math.sqrt(Math.abs(x*x) + Math.abs(y*y)));
	}
	
}