package UID6396f17e149e248a1a98000.nodes.UID5168dc07149e2abaef98000;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_EXCEPTION extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc-buildin-exception-id";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_EXCEPTION";}
		public String toString(){ return "OUTCOME_EXCEPTION";}
		public final String OUTPUT_Error;
		public final static String OUTPUT_ID_Error="Auto generated ERROR_Message id";

		OUTCOME_EXCEPTION(String Error){
			OUTPUT_Error = Error;
		}

		public Object getOutputValue(String outputId){
			if("Auto generated ERROR_Message id".equals(outputId)){
				 return OUTPUT_Error;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Exception(String Error){
		 return new OUTCOME_EXCEPTION( Error);
	}
	protected class OUTCOME_SUCCESS extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID5168dc07149e2abaef97fff";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_SUCCESS";}
		public String toString(){ return "OUTCOME_SUCCESS";}

		OUTCOME_SUCCESS(){
		}

		public Object getOutputValue(String outputId){
			throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Success(){
		 return new OUTCOME_SUCCESS();
	}
	//------- Sink: GetPI [UID5168dc07149e2abaef97ffe]
	interface OUTCOME_INVOKE_CALL_GETPI {
			class OUTCOME_SUCCESS extends XBSOutcome implements OUTCOME_INVOKE_CALL_GETPI{
				private static final long serialVersionUID = 1L;
				public final static String id="UID5168dc07149e2abaef97ffd";
				private String m_ocId=id;
				public String getOutcomeId(){ return m_ocId ;}
				public void resetID(String newID){ m_ocId=newID; }
				public String getOutcomeName(){ return "OUTCOME_SUCCESS";}
				public String toString(){ return "OUTCOME_SUCCESS";}
				public final float OUTPUT_pi;
				public final static String OUTPUT_ID_pi="UID5168dc07149e2abaef97ffb";

				OUTCOME_SUCCESS(float pi){
					OUTPUT_pi = pi;
				}
				private OUTCOME_SUCCESS(XBSOutcome oc){
					OUTPUT_pi = (Float) oc.getOutputValue("UID5168dc07149e2abaef97ffb");				}

				public Object getOutputValue(String outputId){
					if("UID5168dc07149e2abaef97ffb".equals(outputId)){
						 return OUTPUT_pi;
					}
					else throw new RuntimeException("Not found the output");
				}
			}
			class OUTCOME_NotFoundNodeInstance extends XBSOutcome implements OUTCOME_INVOKE_CALL_GETPI{
				private static final long serialVersionUID = 1L;
			}
	}
	protected OUTCOME_INVOKE_CALL_GETPI INVOKE_CALL_GetPI(NodeInstanceHandle handle , int r) throws Exception{
		Map<String, Object> inputs=new HashMap<String, Object>();
		inputs.put("UID5168dc07149e2abaef97ffc", r);
		XBSOutcome oc=super.call(handle, "UID5168dc07149e2abaef97ffe", inputs);
		if(oc==null) throw new Exception("Call interface returns NULL of outcome");
		if(OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS.id.equals(oc.getOutcomeId())){ return new OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS(oc);}
		else if(OC_NotFoundRunningNodeInstance.ID.equals(oc.getOutcomeId())){ return new OUTCOME_INVOKE_CALL_GETPI.OUTCOME_NotFoundNodeInstance(); }
		else if(oc instanceof OC_EngineException){ throw new Exception( (String) oc.getOutputValue(OC_EngineException.ID_Error_Message)); }
		throw new EngineException_Unkown_Outcome(oc.getOutcomeId());
	}
	protected abstract class INVOKE_CALL_CB_GetPI extends AsyncCallBack {
		protected INVOKE_CALL_CB_GetPI(Object value) { super(value); } 
		@Override
		public void back(XBSOutcome outcome) throws NotFoundEntryException {
			OUTCOME_INVOKE_CALL_GETPI oc=null;
			if(outcome.getOutcomeId().equals(OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS.id)) oc=new OUTCOME_INVOKE_CALL_GETPI.OUTCOME_SUCCESS( outcome );
			else throw new NotFoundEntryException("Not found corresponding outcome in callback!?");
			finish(oc);
		}

		abstract void finish(OUTCOME_INVOKE_CALL_GETPI outcome);
	}
	protected AsyncCallOutcome INVOKE_CALL_Asyn_GetPI (NodeInstanceHandle handle, INVOKE_CALL_CB_GetPI cb , Integer r){
		Map<String, Object> inputs=new HashMap<String, Object>();
		inputs.put("UID5168dc07149e2abaef97ffc", r);
		return super.call_async(handle, "UID5168dc07149e2abaef97ffe", inputs, cb);
	}
	// ----------------------------------
}
