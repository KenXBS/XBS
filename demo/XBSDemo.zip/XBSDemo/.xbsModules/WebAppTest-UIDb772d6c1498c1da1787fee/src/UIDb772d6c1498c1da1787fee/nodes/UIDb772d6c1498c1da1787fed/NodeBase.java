package UIDb772d6c1498c1da1787fee.nodes.UIDb772d6c1498c1da1787fed;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_EXCEPTION extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc_service_failed";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_EXCEPTION";}
		public String toString(){ return "OUTCOME_EXCEPTION";}
		public final String OUTPUT_ErrorMessage;
		public final static String OUTPUT_ID_ErrorMessage="oc_service_failed_message_id";

		OUTCOME_EXCEPTION(String ErrorMessage){
			OUTPUT_ErrorMessage = ErrorMessage;
		}

		public Object getOutputValue(String outputId){
			if("oc_service_failed_message_id".equals(outputId)){
				 return OUTPUT_ErrorMessage;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Exception(String ErrorMessage){
		 return new OUTCOME_EXCEPTION( ErrorMessage);
	}
	protected class OUTCOME_START_SUCCESS extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="oc_service_success";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_START_SUCCESS";}
		public String toString(){ return "OUTCOME_START_SUCCESS";}
		public final String OUTPUT_ServiceHandle;
		public final static String OUTPUT_ID_ServiceHandle="output_service_handle_id";

		OUTCOME_START_SUCCESS(String ServiceHandle){
			OUTPUT_ServiceHandle = ServiceHandle;
		}

		public Object getOutputValue(String outputId){
			if("output_service_handle_id".equals(outputId)){
				 return OUTPUT_ServiceHandle;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Start_success(String ServiceHandle){
		 return new OUTCOME_START_SUCCESS( ServiceHandle);
	}
	public XBSOutcome call(String callId, Map<String, Object> inputs) throws NotFoundEntryException{
		if("service_call_stop".equals(callId)) return CALL_Stop_Service();
		else if("UID49b6779b150dd8292f77f81".equals(callId)) return CALL_Auth1((String) inputs.get("UID49b6779b150dd8292f77f94"), (String) inputs.get("UID49b6779b150dd8292f77f95"));
		else if("UID41ca16e11499acbdfe28000".equals(callId)) return CALL_Auth((String) inputs.get("UID41ca16e11499acbdfe27ff2"), (String) inputs.get("UID41ca16e11499acbdfe27ff1"));
		else throw new NotFoundEntryException(callId);
	}
	protected static class OUTCOME_Call_STOP_SERVICE extends XBSOutcome {
		private static final long serialVersionUID = 1L;
		class OUTCOME_SUCCEED extends OUTCOME_Call_STOP_SERVICE{
			private static final long serialVersionUID = 1L;
			public final static String id="service_call_stop_oc_success";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_SUCCEED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_SUCCEED(){
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

		}
		static OUTCOME_Call_STOP_SERVICE Succeed(){
			return new OUTCOME_Call_STOP_SERVICE().new OUTCOME_SUCCEED();
		};
		class OUTCOME_FAILED extends OUTCOME_Call_STOP_SERVICE{
			private static final long serialVersionUID = 1L;
			public final static String id="service_call_stop_oc_failed";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_FAILED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_FAILED(String ErrorMessage){
				m_outputs.put("service_call_stop_oc_failed_output_error", ErrorMessage);
				OUTPUT_ErrorMessage = (String) getOutputValue("service_call_stop_oc_failed_output_error");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_ErrorMessage;
		}
		static OUTCOME_Call_STOP_SERVICE Failed(String ErrorMessage){
			return new OUTCOME_Call_STOP_SERVICE().new OUTCOME_FAILED( ErrorMessage);
		};
	}
	protected abstract OUTCOME_Call_STOP_SERVICE CALL_Stop_Service();
	protected static class OUTCOME_Call_AUTH1 extends XBSOutcome {
		private static final long serialVersionUID = 1L;
		class OUTCOME_BLOCK extends OUTCOME_Call_AUTH1{
			private static final long serialVersionUID = 1L;
			public final static String id="UID49b6779b150dd8292f77f9e";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_BLOCK"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_BLOCK(){
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

		}
		static OUTCOME_Call_AUTH1 Block(){
			return new OUTCOME_Call_AUTH1().new OUTCOME_BLOCK();
		};
		class OUTCOME_SUCCESS extends OUTCOME_Call_AUTH1{
			private static final long serialVersionUID = 1L;
			public final static String id="UID49b6779b150dd8292f77fa6";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_SUCCESS"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_SUCCESS(String UserId){
				m_outputs.put("UID49b6779b150dd8292f77fa0", UserId);
				OUTPUT_UserId = (String) getOutputValue("UID49b6779b150dd8292f77fa0");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_UserId;
		}
		static OUTCOME_Call_AUTH1 Success(String UserId){
			return new OUTCOME_Call_AUTH1().new OUTCOME_SUCCESS( UserId);
		};
		class OUTCOME_FAILED extends OUTCOME_Call_AUTH1{
			private static final long serialVersionUID = 1L;
			public final static String id="oc-buildin-exception-id";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_FAILED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_FAILED(String OldUserName, String OldPwd){
				m_outputs.put("Auto generated ERROR_Message id", OldUserName);
				OUTPUT_OldUserName = (String) getOutputValue("Auto generated ERROR_Message id");
				m_outputs.put("UID49b6779b150dd8292f77fa1", OldPwd);
				OUTPUT_OldPwd = (String) getOutputValue("UID49b6779b150dd8292f77fa1");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_OldUserName;
			String OUTPUT_OldPwd;
		}
		static OUTCOME_Call_AUTH1 Failed(String OldUserName, String OldPwd){
			return new OUTCOME_Call_AUTH1().new OUTCOME_FAILED( OldUserName,  OldPwd);
		};
	}
	protected abstract OUTCOME_Call_AUTH1 CALL_Auth1(String Pwd, String UserName);
	protected static class OUTCOME_Call_AUTH extends XBSOutcome {
		private static final long serialVersionUID = 1L;
		class OUTCOME_FAILED extends OUTCOME_Call_AUTH{
			private static final long serialVersionUID = 1L;
			public final static String id="oc-buildin-exception-id";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_FAILED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_FAILED(String Error){
				m_outputs.put("Auto generated ERROR_Message id", Error);
				OUTPUT_Error = (String) getOutputValue("Auto generated ERROR_Message id");
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

			String OUTPUT_Error;
		}
		static OUTCOME_Call_AUTH Failed(String Error){
			return new OUTCOME_Call_AUTH().new OUTCOME_FAILED( Error);
		};
		class OUTCOME_SUCCEEDED extends OUTCOME_Call_AUTH{
			private static final long serialVersionUID = 1L;
			public final static String id="UID41ca16e11499acbdfe27ff3";
			private String m_ocId=id;
			public String getOutcomeId(){ return m_ocId ;}
			public void resetID(String newID){ m_ocId=newID; }
			public String getOutcomeName() { return "OUTCOME_SUCCEEDED"; }
			public String toString() { return getOutcomeName(); }
			private HashMap<String, Object> m_outputs=new HashMap<String, Object>();
			OUTCOME_SUCCEEDED(){
			}
			public Object getOutputValue(String id){ return m_outputs.get(id); }
			public HashMap<String, Object> getOutputs(){ return m_outputs; }

		}
		static OUTCOME_Call_AUTH Succeeded(){
			return new OUTCOME_Call_AUTH().new OUTCOME_SUCCEEDED();
		};
	}
	protected abstract OUTCOME_Call_AUTH CALL_Auth(String UserId, String Pwd);
	//Event (Out): service_event_stopped
	protected void FireEvent_Service_stopped(){
		Map<String, Object> inputs=new HashMap<String, Object>();
		super.fireEvent("service_event_stopped", inputs);
	}
}
