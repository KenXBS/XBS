package UIDb772d6c1498c1da1787fee.nodes.UIDb772d6c1498c1da1787fed;

import UIDb772d6c1498c1da1787fee.module.*;
import org.apache.log4j.Logger;
import com.kensoft.xbs.xbsEngine.*;
public class XBSNode extends NodeBase {
	private Logger m_logger;
	private final int RETRY_LIMIT = 3;
	private int failedTimes = 0;
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nodeContext=(XBSNodeContext) arg0;
		m_logger=(Logger) nodeContext.getAttribute(XBSNodeContextBase.Sys_Log);
		XBSModuleContext moduleContext=(XBSModuleContext) arg0.getModuleContext();
		
		return nodeContext.Outcome_Start_success(null);
	}
	
	@Override
	protected OUTCOME_Call_AUTH CALL_Auth(String UserId, String Pwd) {
		if("guest".equalsIgnoreCase(UserId) && "trial".equals(Pwd)){
			return OUTCOME_Call_AUTH.Succeeded();
		}else{
			return OUTCOME_Call_AUTH.Failed("Wrong user id or password ! ( Try 'trial' )");
		}
	}

	@Override
	protected OUTCOME_Call_STOP_SERVICE CALL_Stop_Service() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected OUTCOME_Call_AUTH1 CALL_Auth1(String Pwd, String UserId) {
		if("guest".equalsIgnoreCase(UserId) && "trial".equals(Pwd)){
			failedTimes = 0;
			return OUTCOME_Call_AUTH1.Success(UserId);
		}else{
			failedTimes++;
			if(failedTimes >= RETRY_LIMIT ){
				return OUTCOME_Call_AUTH1.Block();
			}else{
				return OUTCOME_Call_AUTH1.Failed(UserId, Pwd);
			}
		}
	}
}