/**
 * The following functions need to be implemented in node implementation file. Do not edit in this file !!! 
 */
XBS.NODE_UID49b6779b150dd8292f77f9d_UID49b6779b150dd8292f77fb3.prototype.start=function(){
	var that = this;
	
	var vp = Ext.ComponentQuery.query('viewport')[0];
	
	vp.removeAll(true);
	
	vp.add(new Ext.create('Ext.panel.Panel', {
		border: false,
		style: 'font-weight: bold',
		html: "Sorry, you have exceeded the maximum retries. <br/><br/>You will be blocked from signing on! <br/><br/>Please contact administrator."
	}));
	
	that.NodeEnd_Finish();
}