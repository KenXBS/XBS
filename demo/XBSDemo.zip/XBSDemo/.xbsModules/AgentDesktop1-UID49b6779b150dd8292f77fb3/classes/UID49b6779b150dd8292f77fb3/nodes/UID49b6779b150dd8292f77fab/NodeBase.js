/**
 * Auto-generated Code for Node: AgentDesk1:Login Form
 */

XBS.NODE_UID49b6779b150dd8292f77fab_UID49b6779b150dd8292f77fb3 = function(nodeIns){
	this.nodeIns=nodeIns;
};
XBS.NODE_UID49b6779b150dd8292f77fab_UID49b6779b150dd8292f77fb3.prototype.run=function(inputs){
	this.start( inputs["UID49b6779b150dd8292f77fa2"], inputs["UID49b6779b150dd8292f77fa3"]);
}
/**
 * Node Outcome: Auth
 */
XBS.NODE_UID49b6779b150dd8292f77fab_UID49b6779b150dd8292f77fb3.prototype.NodeEnd_Auth=function(UserId, Pwd){
	var that=this;
	var outputs={
		"UID49b6779b150dd8292f77fa9" : UserId
		, "UID49b6779b150dd8292f77fa8" : Pwd
	};
	setTimeout(function(){ that.nodeIns.commit("UID49b6779b150dd8292f77faa", outputs);} , 50);
};


/**
 * The following functions need to be implemented in node implementation file. Do not edit in this file !!! 
 */
XBS.NODE_UID49b6779b150dd8292f77fab_UID49b6779b150dd8292f77fb3.prototype.start=function(Pwd,UserName){
	//TODO: need to be coded in separate node implementation file. Do not modify here !!!

	throw "Node start() is not implemented, node: AgentDesk1:Login Form";
}
