XBS.NODE_UID49b6779b150dd8292f77fab_UID49b6779b150dd8292f77fb3.prototype.start=function(Pwd,UserName){
	var that = this;
	
	var vp = Ext.ComponentQuery.query('viewport')[0];
	
	vp.removeAll(true);
	
	vp.add(new Ext.create('Ext.FormPanel', {
		border: false,
		layout: 'anchor',
		bodyPadding: 5,
		defaults: {
			anchor: '100%',
			allowBlank: false
		},
		defaultType: 'textfield',
		items: [{
			fieldLabel: 'User Name',
			value: UserName,
			name: 'user'
		},{
			fieldLabel: 'Password',
			inputType: 'password',
			value: Pwd,
			name: 'pwd',
		}],
		buttons: [{
			text: 'Login',
			handler: function(){
				var bttn=this;
				var form=this.up('form');
				if(form.isValid()){
					var values=form.getValues();
					that.NodeEnd_Auth(values.user, values.pwd);
					return;
				}
			}
        }]
	}));
}