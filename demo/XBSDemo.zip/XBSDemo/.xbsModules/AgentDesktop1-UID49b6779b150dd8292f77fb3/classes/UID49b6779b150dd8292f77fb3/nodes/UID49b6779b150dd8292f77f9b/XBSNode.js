XBS.NODE_UID49b6779b150dd8292f77f9b_UID49b6779b150dd8292f77fb3.prototype.start=function(Pwd,UserName){
	Ext.Msg.alert("Error", "Wrong user name or password !");
	this.NodeEnd_Closed(UserName, Pwd);
}