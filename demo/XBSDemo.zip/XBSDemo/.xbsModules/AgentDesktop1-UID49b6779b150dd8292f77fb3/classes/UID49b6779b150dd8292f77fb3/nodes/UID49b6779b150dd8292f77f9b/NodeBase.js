/**
 * Auto-generated Code for Node: AgentDesk1:Auth Failed Msg
 */

XBS.NODE_UID49b6779b150dd8292f77f9b_UID49b6779b150dd8292f77fb3 = function(nodeIns){
	this.nodeIns=nodeIns;
};
XBS.NODE_UID49b6779b150dd8292f77f9b_UID49b6779b150dd8292f77fb3.prototype.run=function(inputs){
	this.start( inputs["UID49b6779b150dd8292f77f96"], inputs["UID49b6779b150dd8292f77f97"]);
}
/**
 * Node Outcome: Closed
 */
XBS.NODE_UID49b6779b150dd8292f77f9b_UID49b6779b150dd8292f77fb3.prototype.NodeEnd_Closed=function(UserName, Pwd){
	var that=this;
	var outputs={
		"UID49b6779b150dd8292f77f99" : UserName
		, "UID49b6779b150dd8292f77f98" : Pwd
	};
	setTimeout(function(){ that.nodeIns.commit("UID49b6779b150dd8292f77f9a", outputs);} , 50);
};


/**
 * The following functions need to be implemented in node implementation file. Do not edit in this file !!! 
 */
XBS.NODE_UID49b6779b150dd8292f77f9b_UID49b6779b150dd8292f77fb3.prototype.start=function(Pwd,UserName){
	//TODO: need to be coded in separate node implementation file. Do not modify here !!!

	throw "Node start() is not implemented, node: AgentDesk1:Auth Failed Msg";
}
