
	        
XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3.prototype.start=function(){
	var that = this;
	Ext.require(['*']);
	
	Ext.onReady(function() {
		var viewport = Ext.create('Ext.Viewport', {
			id: 'lasdkj',
			layout: {
				type: 'vbox',
				align: 'center',
				pack: 'center',
			}
		});
		that.NodeEnd_Success();
	});
}