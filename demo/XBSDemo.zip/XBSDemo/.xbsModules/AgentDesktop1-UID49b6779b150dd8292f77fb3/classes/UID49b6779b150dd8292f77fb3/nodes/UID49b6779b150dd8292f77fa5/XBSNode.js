XBS.NODE_UID49b6779b150dd8292f77fa5_UID49b6779b150dd8292f77fb3.prototype.start=function(UserId){
var that = this;
	
	var vp = Ext.ComponentQuery.query('viewport')[0];
	
	vp.removeAll(true);
	
	vp.add(new Ext.create('Ext.panel.Panel', {
		border: false,
		style: 'font-weight: bold',
		html: "Welcome, " + UserId + " !" + "<br /><br />( Here will be the main window for your daily work. Under construction ... )"
	}));
}