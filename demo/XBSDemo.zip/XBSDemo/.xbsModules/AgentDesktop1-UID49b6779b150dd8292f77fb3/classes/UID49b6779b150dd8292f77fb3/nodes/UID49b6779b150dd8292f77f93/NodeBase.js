/**
 * Auto-generated Code for Node: AgentDesk1:InitExtJS
 */

XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3 = function(nodeIns){
	this.nodeIns=nodeIns;
};
XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3.prototype.run=function(inputs){
	this.start();
}
/**
 * Node Outcome: Exception
 */
XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3.prototype.NodeEnd_Exception=function(Error){
	var that=this;
	var outputs={
		"Auto generated ERROR_Message id" : Error
	};
	setTimeout(function(){ that.nodeIns.commit("oc-buildin-exception-id", outputs);} , 50);
};
/**
 * Node Outcome: Success
 */
XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3.prototype.NodeEnd_Success=function(){
	var that=this;
	var outputs={
	};
	setTimeout(function(){ that.nodeIns.commit("UID49b6779b150dd8292f77f92", outputs);} , 50);
};


/**
 * The following functions need to be implemented in node implementation file. Do not edit in this file !!! 
 */
XBS.NODE_UID49b6779b150dd8292f77f93_UID49b6779b150dd8292f77fb3.prototype.start=function(){
	//TODO: need to be coded in separate node implementation file. Do not modify here !!!

	throw "Node start() is not implemented, node: AgentDesk1:InitExtJS";
}
