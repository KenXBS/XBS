package UID49b6779b150dd8292f77fb3.module;

import java.util.*;
import java.net.URLEncoder;
import com.kensoft.xbs.xbsEngine.*;
public class XBSModuleContext extends XBSModuleContextBase {
	 public XBSModuleContext(ModuleInstance xbsModuleIns){ super(xbsModuleIns);}
// -- begin of Data
// -- end of Data
// -- begin of Properties
//-- end of Properties
// -- begin of Configures
//-- end of Configures
// -- begin of Actions
//-- end of Actions
// -- begin of Events In
//-- end of Events In
// -- begin of Events Out
//-- end of Events Out
}
