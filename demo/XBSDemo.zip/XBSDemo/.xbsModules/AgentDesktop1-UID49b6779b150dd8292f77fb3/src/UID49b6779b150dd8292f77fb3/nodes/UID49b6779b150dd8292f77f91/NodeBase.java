package UID49b6779b150dd8292f77fb3.nodes.UID49b6779b150dd8292f77f91;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_XBSDEFAULT extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID49b6779b150dd8292f77f90";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_XBSDEFAULT";}
		public String toString(){ return "OUTCOME_XBSDEFAULT";}

		OUTCOME_XBSDEFAULT(){
		}

		public Object getOutputValue(String outputId){
			throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_xbsDefault(){
		 return new OUTCOME_XBSDEFAULT();
	}
}
