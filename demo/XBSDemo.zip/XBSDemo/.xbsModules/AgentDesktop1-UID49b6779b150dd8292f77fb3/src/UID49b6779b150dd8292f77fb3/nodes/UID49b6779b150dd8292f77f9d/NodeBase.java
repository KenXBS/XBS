package UID49b6779b150dd8292f77fb3.nodes.UID49b6779b150dd8292f77f9d;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_FINISH extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID49b6779b150dd8292f77f9c";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_FINISH";}
		public String toString(){ return "OUTCOME_FINISH";}

		OUTCOME_FINISH(){
		}

		public Object getOutputValue(String outputId){
			throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Finish(){
		 return new OUTCOME_FINISH();
	}
}
