package UID49b6779b150dd8292f77fb3.nodes.UID49b6779b150dd8292f77fab;

import com.kensoft.xbs.xbsEngine.*;
import java.util.*;
abstract class NodeBase extends JavaCodeNode_T {
	protected class OUTCOME_AUTH extends XBSOutcome{
		private static final long serialVersionUID = 1L;
		public final static String id="UID49b6779b150dd8292f77faa";
		private String m_ocId=id;
		public String getOutcomeId(){ return m_ocId ;}
		public void resetID(String newID){ m_ocId=newID; }
		public String getOutcomeName(){ return "OUTCOME_AUTH";}
		public String toString(){ return "OUTCOME_AUTH";}
		public final String OUTPUT_UserId;
		public final static String OUTPUT_ID_UserId="UID49b6779b150dd8292f77fa9";
		public final String OUTPUT_Pwd;
		public final static String OUTPUT_ID_Pwd="UID49b6779b150dd8292f77fa8";

		OUTCOME_AUTH(String UserId, String Pwd){
			OUTPUT_UserId = UserId;
			OUTPUT_Pwd = Pwd;
		}

		public Object getOutputValue(String outputId){
			if("UID49b6779b150dd8292f77fa9".equals(outputId)){
				 return OUTPUT_UserId;
			}
			else if("UID49b6779b150dd8292f77fa8".equals(outputId)){
				 return OUTPUT_Pwd;
			}
			else throw new RuntimeException("Not found the output");
		}
	}
	protected XBSOutcome Outcome_Auth(String UserId, String Pwd){
		 return new OUTCOME_AUTH( UserId,  Pwd);
	}
}
