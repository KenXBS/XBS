package UID19b9861f1498bdaae9e7ffc.nodes.UIDb772d6c1498c1da1787ffc;

import java.awt.Desktop;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UID19b9861f1498bdaae9e7ffc.module.*;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kensoft.xbs.common.model.EventStruct;
import com.kensoft.xbs.common.model.GlobalConstants;
import com.kensoft.xbs.common.model.OC_Service_Success;
import com.kensoft.xbs.common.model.OutcomeStruct;
import com.kensoft.xbs.common.model.ParamEntryStruct;
import com.kensoft.xbs.common.model.XBSConnectionEntry;
import com.kensoft.xbs.common.model.XBSConnectionEntry_OC;
import com.kensoft.xbs.common.model.XBSInterface;
import com.kensoft.xbs.xbsEngine.*;

public class XBSNode extends NodeBase {
	class WebApp {
		final String m_moduleInstanceId;
		final Map<String, XBSModule> m_moduleMap;
		final String m_rootPath; //pointing to one level up of '.xmlModules' folder
		final String m_moduleId; //WebApp module id
		
		WebApp(String moduleId, String moduleInstanceId, String rootPath, Map<String, XBSModule> moduleMap){
			m_moduleInstanceId=moduleInstanceId;
			m_rootPath=rootPath; //only XBSAdmin has this value, it's 'null' for other webapp.
			m_moduleMap=moduleMap;
			m_moduleId=moduleId;
		}
	}
	
	private Logger m_logger;
	private Map<String, WebApp> mWebAppMap = new HashMap<String, WebApp>();
	private Map<String, XBSModule> moduleMap = null;
	private ExecutionTree executionMap=new ExecutionTree();
	private String webContentPath=null;
	
	@Override
	public XBSOutcome Execute(XBSNodeContextBase arg0){
		XBSNodeContext nodeContext=(XBSNodeContext) arg0;
		m_logger=(Logger) nodeContext.getAttribute(XBSNodeContextBase.Sys_Log);
		XBSModuleContext moduleContext=(XBSModuleContext) arg0.getModuleContext();
		
		String[] alias = nodeContext.INPUT_Alias.split(";");
		String[] modules = nodeContext.INPUT_Modules.split(";");
		String rootPath = nodeContext.INPUT_RootPath;
		webContentPath = nodeContext.INPUT_WebContentPath;
		
		try {
			moduleMap = ExecuteModules.LoadModuleMap(rootPath, m_logger);
		} catch (Exception e1) {
			e1.printStackTrace();
			return nodeContext.Outcome_Exception("Exception while loading modules: " + e1.getLocalizedMessage());
		}
		
		for(int i=0;i<alias.length; ++i){
			String moduleId = modules[i];
			/* Load XBSModule */
			XBSModule xbsModule;
			try {
				xbsModule = new XBSModule(moduleId, rootPath, moduleMap);
			} catch (Exception e) {
				e.printStackTrace();
				m_logger.error("Failed to load module: " + moduleId);
				continue;
			}
			
			/* Initialize module & start module*/
			ModuleInstance startModuleInstance;
			try {
				xbsModule.load(null);
				
				startModuleInstance = new ModuleInstance(null, false,
						(Logger) m_logger,  
						xbsModule,
						executionMap,
						(Map<String, Object>) null, null, null, null);
			}catch(Exception ex){
				ex.printStackTrace();
				m_logger.error("Failed to init module: " + moduleId);
				continue;
			}
			
			try{
				XBSOutcome oc=startModuleInstance.ExecuteFromNode(null, null, null, null);
				if((xbsModule.isService() || xbsModule.isWebApp()) && oc.getOutcomeId().equals(OC_Service_Success.ID)){
					XBSOutcomeModule ocModule=(XBSOutcomeModule) oc;
					ocModule.setInput(OC_Service_Success.OUTPUT_ServiceHandle_ID, startModuleInstance.getKey());
					executionMap.put(startModuleInstance.getKey(), startModuleInstance);
				}
			}catch(Exception e){
				e.printStackTrace();
				m_logger.error("Failed to execute module: " + moduleId);
				continue;
			}
			
			mWebAppMap.put("/" + alias[i], new WebApp(moduleId, startModuleInstance.getKey(), 
					rootPath, moduleMap));
		}
		
		m_logger.info("App URL: "  +  "http://localhost:" + nodeContext.INPUT_Port + "/" + nodeContext.INPUT_Alias);
		if(Desktop.isDesktopSupported())
		{
			try {
				Desktop.getDesktop().browse(new URI("http://localhost:" + nodeContext.INPUT_Port + "/" + nodeContext.INPUT_Alias));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return nodeContext.Outcome_Start_success(null);
	}
	@Override
	protected OUTCOME_Call_STOP_SERVICE CALL_Stop_Service() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	protected OUTCOME_Call_HTTPREQUEST CALL_HttpRequest(Object HttpRequest,
			Object HttpResponse) {
		HttpServletRequest req=(HttpServletRequest) HttpRequest;
		HttpServletResponse resp=(HttpServletResponse) HttpResponse;
		try{
			if(req.getMethod().equalsIgnoreCase("get")){
				processGetRequest(req, resp);
			}else if(req.getMethod().equalsIgnoreCase("post")){
				processPostRequest(req, resp);
			}
		}catch(Exception ex){
			String errMsg="Exception while processing http request: " + ex.getLocalizedMessage() 
					+ ", url: " + req.getPathInfo();
			m_logger.error(errMsg, ex);
			sendError(resp, errMsg);
		}
		return OUTCOME_Call_HTTPREQUEST.Success();
	}
	
	private static long stream(InputStream input, OutputStream output) throws IOException {
	    ReadableByteChannel inputChannel = null;
	    WritableByteChannel outputChannel = null;

	    try {
	        inputChannel = Channels.newChannel(input);
	        outputChannel = Channels.newChannel(output);
	        ByteBuffer buffer = ByteBuffer.allocate(10240);
	        long size = 0;

	        while (inputChannel.read(buffer) != -1) {
	            buffer.flip();
	            size += outputChannel.write(buffer);
	            buffer.clear();
	        }

	        return size;
	    }
	    finally {
	        if (outputChannel != null) try { outputChannel.close(); } catch (IOException ignore) { /**/ }
	        if (inputChannel != null) try { inputChannel.close(); } catch (IOException ignore) { /**/ }
	    }
	}
	
	private void sendError(HttpServletResponse resp, String errMsg){
		m_logger.error(errMsg);
		JSONObject jsResp=new JSONObject();
		try {
			jsResp.put("success", false);
			jsResp.put("message", errMsg);
		} catch (JSONException e1) {
			m_logger.error("JSON Parse error: " + e1.getLocalizedMessage());
			return;
		}
		
		try {
			resp.getWriter().write(jsResp.toString());
		} catch (IOException e1) {
			//browser closed the connection. do nothing.
		}
	}
	
	private void processGetRequest(HttpServletRequest req, HttpServletResponse resp) throws Exception{
		String alias=req.getPathInfo().toLowerCase();
		WebApp webApp=mWebAppMap.get(alias);
		if(webApp==null){
			File file=new File(webContentPath + req.getPathInfo());
			if(file.isFile() && file.exists() && file.canRead()){
				try {
					FileInputStream in=new FileInputStream(file);
					resp.setContentLength((int) file.length());
					stream(in, resp.getOutputStream());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				resp.setStatus(404);
			}
			
			return;
		}
		
		//start web application, sends /xbsUIFramework.html
		File file=new File(webContentPath + "/XBSUIWebApp.html");
		if(!file.exists()){
			sendError(resp, "Failed to start Web Application. File doesn't exist: " + file.getAbsolutePath());
			return;
		}else{
			byte[] buffer=new byte[(int) file.length()];
			FileInputStream in=new FileInputStream(file);
			in.read(buffer);
			in.close();
		
			StringBuffer content=new StringBuffer(new String(buffer));
			int pos=content.indexOf("{TITLE}");
			if(pos>0){
				content.replace(pos, pos+ "{TITLE}".length(), alias.substring(1));
			}
			try {
				ByteArrayInputStream bis=new ByteArrayInputStream(content.toString().getBytes("UTF-8"));
				resp.setContentLength((int) content.length());
				stream(bis, resp.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				m_logger.error("Exception while stream request file back to browser: " + e.getLocalizedMessage());
			}
		}
	
		return;
		
	}
	
	private JSONObject getParams(HttpServletRequest request) throws Exception {
		JSONObject param=null;
		if (request.getMethod().equals("POST")) {
			InputStream in = request.getInputStream();
			ByteArrayOutputStream out=new ByteArrayOutputStream();
			stream(in, out);
			param=new JSONObject(out.toString("UTF-8"));
		} else {
			
		}
		return param;
	}
	
	/**
	 * Process Web App Start request
	 * @param req
	 * @param resp
	 * @param alias
	 * @param moduleInstanceId
	 * @param ocUI
	 * @throws Exception
	 */
	private void processStartWebApp(HttpServletRequest req, HttpServletResponse resp, String alias, String moduleInstanceId, XBSOutcome_UI ocUI) throws Exception{
		//call 'start session' call 
		HashMap<String, Object> inputs=new HashMap<String, Object>();
		//inputs.put(WebApp_Call_StartSession.INPUT_HttpRequest_ID, req);
		//inputs.put(WebApp_Call_StartSession.INPUT_HttpResponse_ID, resp);

		JSONObject jsResp=new JSONObject();
		
		//send parent module back
		
		WebApp app=mWebAppMap.get(alias);
		if(app==null){
			sendError(resp, "Not found web app in its registered map by alias: " + alias);
			return;
		}
		XBSModule xbsModule= this.getModuleForWebApp(alias, app.m_moduleId);
		
		if(xbsModule==null){
			sendError(resp, "Not found xbsModule in web app's register map. App: " + alias + ", moduleId: " + ocUI.getParentModuleId());
			return;
		}
		jsResp.put("ParentModuleId", xbsModule.getId());
		jsResp.put("ParentModule", getModuleJSON(xbsModule));
		jsResp.put("ParentModuleInstanceId", moduleInstanceId);
		sendSuccessJSONResponse(resp, jsResp);
	}
	
	private void sendSuccessJSONResponse(HttpServletResponse resp, JSONObject jsResult){
		JSONObject jsResp=new JSONObject();
		try {
			jsResp.put("success", true);
			jsResp.put("Result", jsResult);
			byte[] buffer=jsResp.toString().getBytes("UTF-8");
			ByteArrayInputStream in=new ByteArrayInputStream(buffer);
			resp.setHeader("content-type", "text/json");
			resp.setContentLength((int) buffer.length);
			stream(in, resp.getOutputStream());
			in.close();
			resp.flushBuffer();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			m_logger.error("Exception while stream request file back to browser: " + e.getLocalizedMessage());
		}
	}
	private XBSModule getModuleForWebApp(String alias, String moduleId) throws Exception{
		WebApp app=mWebAppMap.get(alias);
		if(app==null){
			throw new Exception("Not found web app by alias: " + alias);
		}
		XBSModule xbsModule = null;
		if(app.m_moduleMap!=null) {//XBS Admin app
			xbsModule = app.m_moduleMap.get(moduleId);
		}
		
		return xbsModule;
		
	}
	
	private JSONObject getXBSNodeJSON(com.kensoft.xbs.xbsEngine.XBSNode xbsNode) throws Exception{
		//nodes
		JSONObject jsNode=new JSONObject();
		jsNode.put("id", xbsNode.getId());
		jsNode.put("name", xbsNode.getName());
		jsNode.put("type", xbsNode.getNodeType());
		jsNode.put("processType", xbsNode.getNodeSubType());
		jsNode.put("isSubmodule", false);
		if(xbsNode instanceof XBSSubmoduleNode){
			XBSSubmoduleNode subNode=(XBSSubmoduleNode) xbsNode;
			jsNode.put("isSubmodule", true);
			jsNode.put("type", subNode.getLinkModule().getType()==XBSModule.TYPE_UI? 
					com.kensoft.xbs.xbsEngine.XBSNode.NODETYPE_UI : com.kensoft.xbs.xbsEngine.XBSNode.NODETYPE_CODE_Java);
			jsNode.put("linkModuleId", subNode.getLinkModule().getId());
		}
		//events in
		JSONObject jsEvents_In=new JSONObject();
		for(EventStruct event : xbsNode.getEvents_In().values()){
			JSONObject jsEvent=new JSONObject();
			jsEvent.put("id", event.getId());
			jsEvent.put("name", event.getName());
			JSONObject jsInputs=new JSONObject();
			for(ParamEntryStruct input : event.getInputs().values()){
				JSONObject jsInput=new JSONObject();
				jsInput.put("dataType", input.getDataType());
				jsInput.put("value", input.getValue());
				jsInputs.put(input.getId(), jsInput);
			}
			jsEvent.put("inputs", jsInputs);
			jsEvents_In.put(event.getId(), jsEvent);
		}
		jsNode.put("events_in", jsEvents_In);

		//events out
		JSONObject jsEvents_Out=new JSONObject();
		for(EventStruct event : xbsNode.getEvents_Out().values()){
			JSONObject jsEvent=new JSONObject();
			jsEvent.put("id", event.getId());
			jsEvent.put("name", event.getName());
			JSONObject jsInputs=new JSONObject();
			for(ParamEntryStruct input : event.getInputs().values()){
				JSONObject jsInput=new JSONObject();
				jsInput.put("dataType", input.getDataType());
				jsInput.put("value", input.getValue());
				jsInputs.put(input.getId(), jsInput);
			}
			jsEvent.put("inputs", jsInputs);
			jsEvents_Out.put(event.getId(), jsEvent);
		}
		jsNode.put("events_out", jsEvents_Out);

		//calls
		JSONObject jsCalls=new JSONObject();
		for(XBSInterface call: xbsNode.getCalls().values()){
			JSONObject jsCall=new JSONObject();
			jsCall.put("id", call.getId());
			jsCall.put("name", call.getName());
			//inputs
			JSONObject jsInputs=new JSONObject();
			for(ParamEntryStruct input : call.getInputs().values()){
				JSONObject jsInput=new JSONObject();
				jsInput.put("dataType", input.getDataType());
				jsInputs.put(input.getId(), jsInput);
			}
			jsCall.put("inputs", jsInputs);

			//Outcomes
			JSONObject jsOCs=new JSONObject();
			for(OutcomeStruct oc: call.getOutcomes().values()){
				JSONObject jsOC=new JSONObject();
				JSONObject jsOutputs=new JSONObject();
				for(ParamEntryStruct output : oc.getOutputs().values()){
					JSONObject jsOutput=new JSONObject();
					jsOutput.put("dataType", output.getDataType());
					jsOutputs.put(output.getId(), jsOutput);
				}
				jsOC.put("outputs", jsOutputs);
				jsOCs.put(oc.getId(), jsOC);
			}
			jsCall.put("outcomes", jsOCs);

			jsCalls.put(call.getId(), jsCall);
		}
		jsNode.put("calls", jsCalls);

		//sinks
		JSONObject jsSinks=new JSONObject();
		for(XBSInterface call: xbsNode.getSinks().values()){
			JSONObject jsCall=new JSONObject();
			jsCall.put("id", call.getId());
			jsCall.put("name", call.getName());
			//inputs
			JSONObject jsInputs=new JSONObject();
			for(ParamEntryStruct input : call.getInputs().values()){
				JSONObject jsInput=new JSONObject();
				jsInput.put("dataType", input.getDataType());
				jsInputs.put(input.getId(), jsInput);
			}
			jsCall.put("inputs", jsInputs);

			//Outcomes
			JSONObject jsOCs=new JSONObject();
			for(OutcomeStruct oc: call.getOutcomes().values()){
				JSONObject jsOC=new JSONObject();
				JSONObject jsOutputs=new JSONObject();
				for(ParamEntryStruct output : oc.getOutputs().values()){
					JSONObject jsOutput=new JSONObject();
					jsOutput.put("dataType", output.getDataType());
					jsOutputs.put(output.getId(), jsOutput);
				}
				jsOC.put("outputs", jsOutputs);
				jsOCs.put(oc.getId(), jsOC);
			}
			jsCall.put("outcomes", jsOCs);

			jsCalls.put(call.getId(), jsCall);
		}
		jsNode.put("sinks", jsCalls);
		
		//inputs
		if(xbsNode.getInputs()!=null){
			JSONObject jsInputs=new JSONObject();
			for(ParamEntryStruct input : xbsNode.getInputs().values()){
				JSONObject jsInput=new JSONObject();
				jsInput.put("id", input.getId());
				jsInput.put("dataType", input.getDataType());
				jsInputs.put(input.getId(), jsInput);
			}
			jsNode.put("inputs", jsInputs);
		}
		
		
		//outcomes
		JSONObject jsOCs=new JSONObject();
		for(OutcomeStruct oc : xbsNode.getOutcomes().values()){
			JSONObject jsOC=new JSONObject();
			jsOC.put("id", oc.getId());
			jsOC.put("name", oc.getName());
			JSONObject jsOutputs=new JSONObject();
			for(ParamEntryStruct output : oc.getOutputs().values()){
				JSONObject jsOutput=new JSONObject();
				jsOutput.put("dataType", output.getDataType());
				jsOutputs.put(output.getId(), jsOutput);
			}
			jsOC.put("outputs", jsOutputs);
			jsOCs.put(oc.getId(), jsOC);
		}
		jsNode.put("outcomes", jsOCs);
		
		return jsNode;
	}
	private JSONObject getModuleJSON(XBSModule module) throws Exception{
		if(!module.isLoaded()) module.load(null);
		JSONObject jsModule=new JSONObject();
		jsModule.put("id", module.getId());
		jsModule.put("name", module.getName());
		jsModule.put("type", module.getType());
		JSONArray jsNodes=new JSONArray();
		//nodes
		for(com.kensoft.xbs.xbsEngine.XBSNode xbsNode : module.getNodeMap().values()){
			JSONObject jsNode=getXBSNodeJSON(xbsNode);
			jsNodes.put(jsNode);
		}
		jsModule.put("nodes", jsNodes);
		//connections
		jsModule.put("connList", getConnListJSON(module));
		return jsModule;
	}
	
	private boolean isUINode(com.kensoft.xbs.xbsEngine.XBSNode xbsNode){
		if(xbsNode instanceof XBSSubmoduleNode){
			XBSSubmoduleNode subNode=(XBSSubmoduleNode) xbsNode;
			return subNode.getLinkModule().getType() == XBSModule.TYPE_UI;
		}else{
			return xbsNode.getNodeType().equals(com.kensoft.xbs.xbsEngine.XBSNode.NODETYPE_UI) ||
					xbsNode.isIFNode();
		}
	}
	
	private JSONArray getConnListJSON(XBSModule xbsModule) throws Exception{
		JSONArray jsConnList=new JSONArray();
		for(Wire wire : xbsModule.getConnList()){
			JSONObject jsConn=new JSONObject();
			if(wire.getSourceNode()==null || wire.getTargetNode()==null) continue;
			if(!isUINode(wire.getSourceNode()) && !isUINode(wire.getTargetNode())) continue;
			jsConn.put("sourceNodeId", wire.getSourceNode().getId());
			jsConn.put("sourceId", wire.getSourceId());
			jsConn.put("targetNodeId", wire.getTargetNode().getId());
			if(wire.getTargetId()!=null) jsConn.put("targetId", wire.getTargetId());
			JSONArray jsEntries=new JSONArray();
			JSONObject jsEntries_OC=new JSONObject();
			for(XBSConnectionEntry entry : wire.getEntries().values()){
				if(entry instanceof XBSConnectionEntry_OC){
					XBSConnectionEntry_OC ocEntry=(XBSConnectionEntry_OC) entry;
					JSONObject jsEntry_OC=new JSONObject();
					jsEntry_OC.put("targetOCId", entry.getInputId());
					jsEntry_OC.put("sourceOCId", ocEntry.getValue());
					JSONObject jsOutputEntries=new JSONObject();
					for(XBSConnectionEntry oc2Entry : ocEntry.getEntries().values()){
						JSONObject jsEntry=new JSONObject();
						jsEntry.put("inputId", oc2Entry.getInputId());
						jsEntry.put("sourceType", oc2Entry.getSourceType());
						jsEntry.put("value", oc2Entry.getValue());
						jsOutputEntries.put(oc2Entry.getInputId(), jsEntry);
					}
					jsEntry_OC.put("outputs", jsOutputEntries);
					jsEntries_OC.put(entry.getInputId(), jsEntry_OC);
				}else{
					JSONObject jsEntry=new JSONObject();
					jsEntry.put("inputId", entry.getInputId());
					jsEntry.put("sourceType", entry.getSourceType());
					jsEntry.put("value", entry.getValue());
					jsEntries.put(jsEntry);
				}
			}
			
			jsConn.put("inputEntries", jsEntries);
			if(jsEntries_OC.length()>0) jsConn.put("outcomeEntries", jsEntries_OC);
			jsConnList.put(jsConn);
		}
		
		return jsConnList;
	}
	
	private void processLoadNode(HttpServletRequest req,
			HttpServletResponse resp, JSONObject param, String alias) throws Exception{
		String nodeId=param.getString("nodeId");
		if(nodeId==null) throw new Exception("Missing 'nodeId' in LoadNode request");
		String moduleId=param.getString("moduleId");
		if(moduleId==null) throw new Exception("Missing 'moduleId' in LoadNode request");
		
		
		XBSModule parentModule= this.getModuleForWebApp(alias, moduleId);
		if(parentModule==null){
			sendError(resp, "Not found parent xbsmodule for 'LoadNode' request");
			return;
		}
		
		com.kensoft.xbs.xbsEngine.XBSNode xbsNode=(com.kensoft.xbs.xbsEngine.XBSNode) parentModule.getNodeMap().get(nodeId);
		if(xbsNode==null){
			sendError(resp, "Not found XBS node, for 'LoadNode' request. Node Id: " + nodeId +", module: " + parentModule.getName());
			return;
		}
		
		if(xbsNode instanceof XBSSubmoduleNode){
			XBSSubmoduleNode subNode=(XBSSubmoduleNode) xbsNode;
			JSONObject jsModule=getModuleJSON(subNode.getLinkModule());
			//find start node
			XBSModule submodule=subNode.getLinkModule();
			for(Wire wire: submodule.getConnList()){
				if(wire.getSourceNode().getId().equals(submodule.getId())){
					jsModule.put("startNodeId", wire.getTargetNode().getId());
					break;
				}
			}
			sendSuccessJSONResponse(resp, jsModule);
			
		}else{
			WebApp webApp=mWebAppMap.get(alias);
			if(webApp==null){
				sendError(resp, "Not found related web app.");
				return;
			}
			
			String rootPath = webApp.m_rootPath;
			
			//find module root folder
			File moduleRootFolder = null;
			File rootFolder = new File(rootPath + "/.xbsModules/");
			File[] moduleFolders = rootFolder.listFiles();
			for(File moduleFolder : moduleFolders){
				if(moduleFolder.isDirectory() && moduleFolder.getName().indexOf(moduleId)>=0){
					moduleRootFolder = moduleFolder;
					break;
				}
			}
			if(moduleRootFolder == null) {
				sendError(resp, "Not found module folder. path: " + rootFolder.getAbsolutePath() + ", module id: " + moduleId);
				return;
			}
			//find node classes folder
			File nodeFolder= new File(moduleRootFolder.getAbsolutePath() + "/target/classes/" + 
					GlobalConstants.getJavaPackage_Nodes(moduleId).replaceAll("\\.", "/") + "/" + nodeId);
			if(!nodeFolder.exists()) {
				nodeFolder= new File(moduleRootFolder.getAbsolutePath() + "/classes/" + 
						GlobalConstants.getJavaPackage_Nodes(moduleId).replaceAll("\\.", "/") + "/" + nodeId);
			}
			if(!nodeFolder.exists()) {
				sendError(resp, "Not found node folder. path: " + nodeFolder.getAbsolutePath());
				return;
			}
			
			File[] files=nodeFolder.listFiles();
			Arrays.sort(files);
			resp.setHeader("Content-Type", "text/javascript");
			OutputStream out=resp.getOutputStream();
			//ByteBuffer js=new Buffer();
			for(File file : files){
				if(file.isDirectory() || !file.getName().endsWith(".js")) continue;
				byte[] buf=new byte[(int) file.length()];
				FileInputStream in=new FileInputStream(file);
				try{
					//stream(in, resp.getOutputStream());
					in.read(buf);
					resp.getOutputStream().write(buf);
				}catch(IOException ex){
					//client closed the connection?
					return;
				}
				in.close();
			}
			out.flush();
		}
	}

	private void processLoadModule(HttpServletRequest req,
			HttpServletResponse resp, JSONObject params, String alias) throws Exception {

		String moduleId=params.getString("moduleId");
		if(moduleId==null) throw new Exception("Missing 'moduleId' in LoadModule request");


		XBSModule xbsModule = this.getModuleForWebApp(alias, moduleId);
		if(xbsModule==null){
			sendError(resp, "Not found parent xbsmodule for 'LoadModule' request");
			return;
		}
		
		sendSuccessJSONResponse(resp, getModuleJSON(xbsModule));

	}

	/**
	 * Re-establish node instance chain, for UI to invoke call or execute a node
	 * @param jsNodeInstances calling node's instance info, in JSON format
	 * @param xbsNode calling node, to get module map from
	 * @return processing node instance
	 * @throws Exception
	 */
	private NodeInstance recoverNodeInsChain(String jsNodeInstances, com.kensoft.xbs.xbsEngine.XBSNode xbsNode) throws Exception{
		Map<String, XBSModule> xbsModuleMap=xbsNode.getParentModule().getContainingModuleMap();
	
		/* find all node instances and make a chain */
		ArrayList<JSONObject> nodeInsChain=new ArrayList<JSONObject>();
		JSONObject jsNodeIns=new JSONObject(jsNodeInstances);
		nodeInsChain.add(jsNodeIns);
		while(true){
			JSONObject jsModuleIns=jsNodeIns.getJSONObject("parentModuleIns");
			if(jsModuleIns.has("parentNodeIns")){
				jsNodeIns=jsModuleIns.getJSONObject("parentNodeIns");
				nodeInsChain.add(jsNodeIns);
			}else {
				break;
			}
		}
		
		
		/* Initialize instance chain */
		NodeInstance nodeIns=null;
		for(int i=nodeInsChain.size()-1; i >= 0; --i){
			jsNodeIns=nodeInsChain.get(i);
			JSONObject jsParentModuleIns=jsNodeIns.getJSONObject("parentModuleIns");
			String nodeId=jsNodeIns.getString("nodeId");
			if(nodeId==null) throw new Exception("Missing 'nodeId' in request");
			String moduleId=jsParentModuleIns.getString("moduleId");
			if(moduleId==null) throw new Exception("Missing 'moduleId' in request");
			String moduleInsId=jsParentModuleIns.getString("moduleInsId");
			if(moduleInsId==null) throw new Exception("Missing 'moduleInsId' in request");
			XBSModule xbsModule=xbsModuleMap.get(moduleId);
			if(xbsModule==null) throw new Exception("Not found module in the application's module list. Module ID: " + moduleId);
			xbsNode=xbsModule.getNodeMap().get(nodeId);
			if(xbsNode==null) throw new Exception("Not found node in module: " + xbsModule.getName() + ", Node Id: " + nodeId);
			
			ModuleInstance moduleIns=(ModuleInstance) executionMap.get(moduleInsId);
			if(moduleIns==null){
				/* Module Inputs */
				Map<String, Object> moduleInputs=new HashMap<String, Object>();
				if(jsParentModuleIns.has("inputs")){
					Map<String, ParamEntryStruct> inputs=xbsModule.getInputs();
					JSONObject jsNodeInputs=jsParentModuleIns.getJSONObject("inputs");
					for(ParamEntryStruct input : inputs.values()){
						String key=input.getId();
						if(jsNodeInputs.has(key)){
							String dataType=input.getDataType();
							if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_String])) moduleInputs.put(key, jsNodeInputs.getString(key));
							else if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_Integer])) moduleInputs.put(key, jsNodeInputs.getInt(key));
							else throw new Exception("Unknown UI data type");
						}else{
							moduleInputs.put(key, null);
						}
					}
				}
				
				
				moduleIns=new ModuleInstance(null, false, m_logger, 
						xbsModule, 
						executionMap, 
						moduleInputs, null, nodeIns, null);
				moduleIns.setKey(moduleInsId);
			}
			
			/* Node Inputs */
			HashMap<String, Object> nodeInputs=new HashMap<String, Object>();
			if(jsNodeIns.has("inputs")){
				Map<String, ParamEntryStruct> inputs=null;
				if(jsNodeIns.has("callId")){
					String callId=jsNodeIns.getString("callId");
					XBSInterface call=(XBSInterface) xbsNode.getCalls().get(callId);
					if(call==null) throw new Exception("Not found call by id: " + callId);
					inputs=(call).getInputs();
				}else{
					inputs=xbsNode.getInputs();
				}
				JSONObject jsNodeInputs=jsNodeIns.getJSONObject("inputs");
				for(ParamEntryStruct input : inputs.values()){
					String key=input.getId();
					if(jsNodeInputs.has(key)){
						String dataType=input.getDataType();
						if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_String])) nodeInputs.put(key, jsNodeInputs.getString(key));
						else if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_Integer])) nodeInputs.put(key, jsNodeInputs.getInt(key));
						else throw new Exception("Unknown UI data type");
					}else{
						nodeInputs.put(key, null);
					}
				}
			}
			
			nodeIns=new NodeInstance(moduleIns, xbsNode, nodeInputs);
			nodeIns.setKey(jsNodeIns.getString("instanceId"));
		}
		
		return nodeIns;
	}
	
	protected XBSOutcome CALL_MakeCallOnRunningNode(String InstanceId, 
			String CallId, Object Inputs, Object XBSNode, String callingNodeInsJSON) throws Exception{
		com.kensoft.xbs.xbsEngine.XBSNode xbsNode=(com.kensoft.xbs.xbsEngine.XBSNode) XBSNode;
		Object instance=null;
		if(InstanceId!=null) {
			instance=executionMap.get(InstanceId);
			if(instance==null) throw new Exception("Not found Instance by Id: " + InstanceId);
		}else{//find the first instance of the node
			for(Object obj : executionMap.values()){
				if(obj instanceof NodeInstance){
					NodeInstance nodeIns=(NodeInstance) obj;
					if(nodeIns.getNodeStruct().getId().equals(xbsNode.getId())){
						instance=nodeIns;
						break;
					}else if(nodeIns.getNodeStruct() instanceof XBSSubmoduleNode){
						XBSSubmoduleNode subNode=(XBSSubmoduleNode) nodeIns.getNodeStruct();
						if(subNode.getLinkModule().getId().equals(xbsNode.getParentModule().getId())){
							instance=nodeIns.getLinkModule().getFirstNodeInstance(xbsNode.getId());
							if(instance!=null){
								break;
							}
						}
					}
				}else{
					ModuleInstance moduleIns=(ModuleInstance) obj;
					if(moduleIns.getXBSModule().getId().equals(xbsNode.getParentModule().getId())){
						instance=moduleIns.getFirstNodeInstance(xbsNode.getId());
						if(instance!=null) break;
					}
				}
			}
			
			if(instance == null){
				NodeInstance callingNodeIns=null;
				try {
					callingNodeIns=this.recoverNodeInsChain(callingNodeInsJSON, xbsNode);
				} catch (Exception e) {
					e.printStackTrace();
					m_logger.error("Failed to create node instance chain", e);
					throw new Exception(
							"Exception while calling 'MakeCallOnRunningNode': Failed to create node instance chain: " + e.getLocalizedMessage());
				}
				if(xbsNode instanceof XBSSubmoduleNode){
					XBSSubmoduleNode submoduleNode=(XBSSubmoduleNode) xbsNode;
				
					if(submoduleNode.isStub()){
						try {
							instance=submoduleNode.createInstance(callingNodeIns.getParentModule(), (Map<String, Object>) Inputs);
						} catch (Exception e) {
							e.printStackTrace();
							m_logger.error("Failed to create node instance", e);
							throw new Exception("Failed to create node instance: " + e.getLocalizedMessage());
						}
					}else if(((Map<String, Object>) Inputs).size()==0){//if no need input, create a node instance and run it, to be called
						try {
							instance=submoduleNode.createInstance(callingNodeIns.getParentModule(), (Map<String, Object>) Inputs);
						} catch (Exception e) {
							e.printStackTrace();
							m_logger.error("Failed to create node instance", e);
							throw new Exception("Failed to create node instance: " + e.getLocalizedMessage());
						}
						try {
							((NodeInstance) instance).run(null, null);
						} catch (Exception e) {
							e.printStackTrace();
							m_logger.error("Failed to execute node instance", e);
							throw new Exception("Failed to execute node instance: " + e.getLocalizedMessage());
						}
					}
				}else if(xbsNode.getInputs().size()==0){
					try {
						instance=new NodeInstance(callingNodeIns.getParentModule(), xbsNode, null);
					} catch (Exception e) {
						e.printStackTrace();
						m_logger.error("Failed to create node instance", e);
						throw new Exception("Failed to create node instance: " + e.getLocalizedMessage());
					}
				}
			}
			if(instance==null){
				throw new Exception("Exception while calling 'MakeCallOnRunningNode': Not found Instance by node Id: " + xbsNode.getId());
			}
		}
		
		XBSOutcome oc=null;
		if(instance instanceof ModuleInstance){
			if(CallId==null) {
				m_logger.error("Call Id is null !?");
				throw new Exception("Call id is null!?");
			}
			ModuleInstance moduleIns=(ModuleInstance) instance;
			try {
				oc=moduleIns.ExecuteCall(null, CallId, (Map<String, Object>) Inputs);
				
			} catch (Exception e) {
				throw new Exception("Exception while executing module: " + moduleIns.getName() + ": " + e.getLocalizedMessage());
			}
		}else{//node instance
			NodeInstance nodeIns=(NodeInstance) instance;
			try {
				if(CallId==null){
					oc=nodeIns.run(null, null);
				}else{
					oc=nodeIns.invokeCall((Map<String, Object>) Inputs, CallId);
				}
			} catch (Exception e) {
				m_logger.error("Failed to execute node instance. Node: " + nodeIns.getNodeName(), e);
				throw new Exception("Exception while executing module: " + nodeIns.getNodeName() 
						+ ": " + e.getLocalizedMessage());
			}
		}
		
		return oc;
	}
	
	protected XBSOutcome CALL_MakeCallOnNewNode(String ModuleId,
			String NodeId, Object ModuleInputs, Object NodeInputs,
			String RootModuleInsId, String CallId) throws Exception{
		ModuleInstance rootModuleIns=(ModuleInstance) executionMap.get(RootModuleInsId);
		
		NodeInstance nodeIns=null;
		Map<String, XBSModule> moduleMap=rootModuleIns.getXBSModule().getContainingModuleMap();
		XBSModule module=moduleMap.get(ModuleId);
		com.kensoft.xbs.xbsEngine.XBSNode node=module.getNodeMap().get(NodeId);
		try {
			ModuleInstance moduleIns=new ModuleInstance(null, false,
					(Logger) rootModuleIns.getLog(),  
					module,
					executionMap,
					null, null, null, null);

			nodeIns=new NodeInstance(moduleIns, node, (Map<String, Object>) NodeInputs);

		} catch (Exception e) {
			m_logger.error("Failed to create module instance. Module: " + module.getName(), e);

			throw new Exception("Failed to create module instance. Error: " + e.getLocalizedMessage());
		}

		if(CallId==null){
			
			try {
				XBSOutcome oc = nodeIns.run(null, null);
				return oc;
			} catch (Exception e) {
				m_logger.error("Failed to execute node instance. Node: " + nodeIns.getNodeName(), e);
				
				throw new Exception("Failed to create module instance. Error: " + e.getLocalizedMessage());
			}
		
		}else{
			try {
				@SuppressWarnings("unchecked")
				XBSOutcome oc =nodeIns.invokeCall((Map<String, Object>) NodeInputs, CallId);
				return oc;
			} catch (Exception e) {
				m_logger.error("Failed to execute node instance. Node: " + nodeIns.getNodeName(), e);
				
				throw new Exception("Failed to create module instance. Error: " + e.getLocalizedMessage());
			}
		}
	}

	
	private void processUIMakeCall(HttpServletRequest req,
			HttpServletResponse resp, JSONObject param, String alias) throws Exception{
		WebApp app=mWebAppMap.get(alias);
		if(app==null){
			sendError(resp, "Not found web app registered map, Alias: " + alias);
			return;
		}
		String nodeId=param.getString("calleeNodeId");
		if(nodeId==null) throw new Exception("Missing 'nodeId' in LoadNode request");
		JSONObject jsCallingNodeIns=param.getJSONObject("callingNodeIns");
		JSONObject jsModuleIns=jsCallingNodeIns.getJSONObject("parentModuleIns");
		String moduleId=jsModuleIns.getString("moduleId");
		if(moduleId==null) throw new Exception("Missing 'moduleId' in LoadNode request");
		XBSModule xbsModule=this.getModuleForWebApp(alias, moduleId);
		if(xbsModule==null) throw new Exception("Not found module in '" + alias + "'s module list. Module ID: " + moduleId);
		com.kensoft.xbs.xbsEngine.XBSNode calleeXBSNode=xbsModule.getNodeMap().get(nodeId);//the node invoke call from
		if(calleeXBSNode==null) throw new Exception("Not found node in module. Alias: " 
				+ alias+ ", Module name: " + xbsModule.getName() + ", Node Id: " + nodeId);
		
		XBSOutcome ocCall=null;
		HashMap<String, Object> nodeInputs=new HashMap<String, Object>();
		if(param.has("calleeNodeInputs")){
			Map<String, ParamEntryStruct> inputs=null;
			if(param.has("callId")){
				String callId=param.getString("callId");
				XBSInterface call=(XBSInterface) calleeXBSNode.getCalls().get(callId);
				if(call==null) throw new Exception("Not found call by id: " + callId);
				inputs=(call).getInputs();
			}else{
				inputs=calleeXBSNode.getInputs();
			}
			JSONObject jsNodeInputs=param.getJSONObject("calleeNodeInputs");
			for(ParamEntryStruct input : inputs.values()){
				String key=input.getId();
				if(jsNodeInputs.has(key)){
					String dataType=input.getDataType();
					if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_String])) nodeInputs.put(key, jsNodeInputs.getString(key));
					else if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_Integer])) {
						String value=jsNodeInputs.getString(key);
						if(value.length()>0) nodeInputs.put(key,  Integer.parseInt(value));
						else nodeInputs.put(key, 0);
					}else if(dataType.equals(GlobalConstants.XBSDataType[GlobalConstants.XBSDataType_Long])) {
						String value=jsNodeInputs.getString(key);
						if(value.length()>0) nodeInputs.put(key,  Long.parseLong(value));
						else nodeInputs.put(key, 0);
					}
					else throw new Exception("Unknown UI data type");
				}else{
					nodeInputs.put(key, null);
				}
			}

		}
		if(param.has("callId")){//make call to existing node
			String callId=param.getString("callId");
			String nodeInstanceId=param.has("nodeInstanceId")? param.getString("calleeNodeInstanceId") : null;
			try{
				ocCall=CALL_MakeCallOnRunningNode(nodeInstanceId, callId, nodeInputs, calleeXBSNode, jsCallingNodeIns.toString());
			}catch(Exception ex){
				sendError(resp, ex.getLocalizedMessage());
				return;
			}
		}else{//create a new instance and make call
			
			try{
				ocCall=CALL_MakeCallOnNewNode(moduleId, nodeId, new HashMap<String, Object>(), 
						nodeInputs, app.m_moduleInstanceId, param.has("callId")? param.getString("callId") : null);
			}catch(Exception ex){
				sendError(resp, ex.getLocalizedMessage());
				return;
			}
			
		}
		
		if(ocCall==null){
			String callName="";
			String callId=param.has("callId")? param.getString("callId") : null;
			if(callId!=null){
				XBSInterface callIF=calleeXBSNode.getCalls().get(callId);
				if(callIF!=null) callName=callIF.getName();
			}
			sendError(resp, "Fail to make call on " + calleeXBSNode.getName() + " : the call [ " + callName + " ] returns null ! It's not implemented yet ?");
			return;
		}
		
		/*
		 * Convert outcome to JSON
		 */
		
		/* If outcome is from stub node, the outcome was set, 
		 * otherwise, find & set outcome struct 
		 */
		if(ocCall.getOutcomeJSON()==null){
			OutcomeStruct ocStruct=null;
			if(param.has("callId")){
				XBSInterface call=calleeXBSNode.getCalls().get(param.get("callId"));
				ocStruct=call.getOutcomes().get(ocCall.getOutcomeId());
			}else{
				ocStruct=calleeXBSNode.getOutcomes().get(ocCall.getOutcomeId());
			}
			ocCall.setOutcomeStruct(ocStruct);
		}
		JSONObject jsOutcome=ocCall.getOutcomeJSON();
		
		sendSuccessJSONResponse(resp, jsOutcome);
		
	}
	
	private XBSOutcome execNodeForUI(Object XBSNode, String jsNodeInstances) throws Exception{
		NodeInstance nodeIns=null;
		try{
			nodeIns=this.recoverNodeInsChain(jsNodeInstances, (com.kensoft.xbs.xbsEngine.XBSNode) XBSNode);
		}catch(Exception e){
			e.printStackTrace();
			m_logger.error("Failed to create node instances chain on server side: ", e);
			throw new Exception("Exception while calling 'ExecNodeForUI' and create node instance chain: " + e.getLocalizedMessage());
		}
		/* Execute the current node */
		XBSOutcome oc;
		try {
			oc=nodeIns.run(null, null);
		} catch (Exception e) {
			m_logger.error("Exception while running node: " + nodeIns.getNodeStruct().getName() + ".", e);
			throw new Exception("Exception while running node: " + e.getLocalizedMessage());
		}
		
		return oc;
	}
	private void processExecNode(HttpServletRequest req,
			HttpServletResponse resp, JSONObject param1, String alias) throws Exception {

		JSONObject jsNodeIns=param1.getJSONObject("nodeIns");
		JSONObject jsParentModuleIns=jsNodeIns.getJSONObject("parentModuleIns");
		XBSModule xbsModule = this.getModuleForWebApp(alias, jsParentModuleIns.getString("moduleId"));

		com.kensoft.xbs.xbsEngine.XBSNode xbsNode=xbsModule.getNodeMap().get(jsNodeIns.getString("nodeId"));

		/* Make call to Execution Module */

		XBSOutcome ocNode = null;
		try{
			ocNode = execNodeForUI(xbsNode, jsNodeIns.toString());
		}catch(Exception ex){
			sendError(resp,ex.getLocalizedMessage());
			return;
		}

		/**
		 * Convert outcome to JSON
		 */
		OutcomeStruct ocStruct=null;
		ocStruct=xbsNode.getOutcomes().get(ocNode.getOutcomeId());

		ocNode.setOutcomeStruct(ocStruct);
		JSONObject jsOutcome=ocNode.getOutcomeJSON();

		sendSuccessJSONResponse(resp, jsOutcome);

	}
	
	private void processPostRequest(HttpServletRequest req, HttpServletResponse resp) throws Exception{
		String alias=req.getPathInfo().toLowerCase();
		WebApp webApp=mWebAppMap.get(alias);
		if(webApp==null){
			sendError(resp, "Not found related web app.");
			return;
		}
		JSONObject params=getParams(req);
		String cmd=params.getString("cmd");
		if(cmd==null) {
			sendError(resp, "Missing cmd param in POST request: " + req.getPathInfo() + "?" + req.getQueryString());
			return;
		}
		
		XBSOutcome_UI ocUI=null;
		if(cmd.equalsIgnoreCase("StartWebApp")){
				processStartWebApp(req, resp, alias, webApp.m_moduleInstanceId, ocUI);
		}else if(cmd.equalsIgnoreCase("LoadNode")){
			processLoadNode(req, resp, params, alias);
		}else if(cmd.equalsIgnoreCase("LoadModule")){
			processLoadModule(req, resp, params, alias);
		}else if(cmd.equalsIgnoreCase("UIMakeCall")){
			processUIMakeCall(req, resp, params, alias);
		}else if(cmd.equalsIgnoreCase("ExecuteNode")){
			processExecNode(req, resp, params, alias);
		}else if(cmd.equalsIgnoreCase("ExecuteModule")){
		}else{
			sendError(resp, "Unknown cmd : " + cmd);
		}

	}
}

