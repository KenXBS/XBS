package UID52467ddc140738918198000.nodes.UIDb9a184a14073e4ab8a8000;

import javax.servlet.Servlet;

import org.apache.catalina.core.StandardWrapper;

class XBSServerHttpWrapper extends StandardWrapper {

	XBSServerHttpWrapper(Servlet servlet){
		super.instance=servlet;
	}
	@Override
	public String getName() {
		if(super.instance!=null) return super.instance.toString();
		else return "";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 4213941272840960833L;

}
